Fonts
Gudea http://www.google.com/fonts/specimen/Gudea

Font Awesome Icons
fa-facebook
fa-twitter
fa-pinterest
fa-instagram
fa-google-plus